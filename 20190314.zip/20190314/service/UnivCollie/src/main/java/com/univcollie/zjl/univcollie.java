package com.univcollie.zjl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;

@SpringBootApplication
@Configuration
public class univcollie {

    public static void main(String[] args) {
        SpringApplication.run(univcollie.class, args);
    }
}
